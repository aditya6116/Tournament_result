Project : Catalog Project

Project Libraries used : python, flask, sqlite.

Description : The project is mainly to create a restaurant with                         secured login test tournament results
             
How to run : 1) Download the Latest version of virtual machine.

             2) Download and install Vagrant.

             3) Clone or Download the VM configuration files.

'            4) Run the command 'vagrant up' in your terminal.               
             5) Run the command 'vagrant ssh'.

	     6) Change the directory to '/vagrant/catalog/'.
	
	     7.) To create the database run python database_setup.py

	     8.) To populate the database run python lotsofmenus.py

	     9) Run the project.py with python in terminal.

             10) The server will run on https://localhost:5000      


